package com.Library;

mport java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class UserController extends HttpServlet {

	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String email = req.getParameter("user_email");
		String pass = req.getParameter("user_password");

		boolean user = UserService.addUser(email, pass);

		if (user) {
			System.out.println("new user acc created");
		} else {
			System.out.println("try again");
		}

	}
	

}
